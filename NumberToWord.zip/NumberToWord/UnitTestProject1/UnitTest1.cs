﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using NumberConverterToText;
using System.Collections.Generic;

namespace UnitTestProject1
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestLotsOfNumbers()
		{
			int i = 0;
			int[] numbers = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 19, 21, 32, 54, 76, 98, 
								100, 101, 211, 825, 999, 1100, 5101, 23211, 785825,
								1000000, 2010203, 20102030, 34567890, 999999999, (int)2e9+3 };
			string[] expectedResult = { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", 
										"Ten", "Eleven", "Twelve", "Thirteen", "Seventeen", "Nineteen",
										"Twenty One", "Thirty Two", "Fifty Four", "Seventy Six", "Ninety Eight",
										"One Hundred", "One Hundred One", "Two Hundred Eleven", "Eight Hundred Twenty Five",
										"Nine Hundred Ninety Nine",	"One Thousand, One Hundred", "Five Thousand, One Hundred One", 
										"Twenty Three Thousand, Two Hundred Eleven", 
										"Seven Hundred Eighty Five Thousand, Eight Hundred Twenty Five",
										"One Million", "Two Million, Ten Thousand, Two Hundred Three", 
										"Twenty Million, One Hundred Two Thousand, Thirty",
										"Thirty Four Million, Five Hundred Sixty Seven Thousand, Eight Hundred Ninety",
										"Nine Hundred Ninety Nine Million, Nine Hundred Ninety Nine Thousand, Nine Hundred Ninety Nine",
										"Two Billion, Three"};
			foreach (int n in numbers)
			{
				string s = Converter.ConvertNumberToString(n);
				Assert.AreEqual(expectedResult[i++], s);
			}
		}

		/* Testing these methods individually would require changing them from private to public. 
		[TestMethod]
		public void TestDigits()
		{
			int i = 0;
			int[] digits = Enumerable.Range(0, 9).ToArray();
			string[] expectedResult = { "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
			foreach (int d in digits)
			{
				string s = Converter.ConvertDigitToString(d);
				Assert.AreEqual(expectedResult[i++], s);
			}
		}

		[TestMethod]
		public void TestHighTens()
		{
			int i = 0;
			int[] tens = { 21, 32, 54, 76, 98 };
			string[] expectedResult = { "twenty-one", "thirty-two", "fifty-four", "seventy-six", "ninety-eight" };
			foreach (int n in tens)
			{
				string s = Converter.ConvertHighTensToString(n);
				Assert.AreEqual(expectedResult[i++], s);
			}
		}

		[TestMethod]
		public void TestTeens()
		{
			int i = 0;
			int[] teens = { 10, 11, 12, 13, 19 };
			string[] expectedResult = { "ten", "eleven", "twelve", "thirteen", "nineteen" };
			foreach (int n in teens)
			{
				string s = Converter.ConvertNumberToString(n);
				Assert.AreEqual(expectedResult[i++], s);
			}
		}
		 */
		
	}
}
